﻿const fs = require('fs-extra')
if (fs.existsSync('.env')) require('dotenv').config({ path: __dirname+'/.env' })


//═══════[Required Variables]════════\\
global.audio= "" ;  
global.video= "" ;
global.port =process.env.PORT
global.appUrl=process.env.APP_URL || ""                       // put your app url here,
global.email ="saimsamsun789@gmail.com"
global.location="Lahore,Pakistan."


global.mongodb= process.env.MONGODB_URI || "mongodb+srv://Javan:<29122004J>@cluster0.wj3trzu.mongodb.net/"
global.allowJids= process.env.ALLOW_JID || "null" 
global.blockJids= process.env.BLOCK_JID || "null"
global.DATABASE_URL = process.env.DATABASE_URL || ""

global.timezone= process.env.TZ || process.env.TIME_ZONE || "Asia/Karachi";
global.github=process.env.GITHUB|| "https://github.com/SuhailTechInfo/Suhail-Md";
global.gurl  =process.env.GURL  || "https://whatsapp.com/channel/0029Va9thusJP20yWxQ6N643";
global.website=process.env.GURL || "https://whatsapp.com/channel/0029Va9thusJP20yWxQ6N643" ; 
global.THUMB_IMAGE = process.env.THUMB_IMAGE || process.env.IMAGE || "https://github.com/SuhailTechInfo/Suhail-Md/blob/main/lib/assets/suhail.jpg?raw=true" ; // SET LOGO FOR IMAGE 



global.devs = "923184474176" // Developer Contact
global.sudo = process.env.SUDO ? process.env.SUDO.replace(/[\s+]/g, '') : "null";
global.owner= process.env.OWNER_NUMBER ? process.env.OWNER_NUMBER.replace(/[\s+]/g, '') : "255694187008";




//========================= [ BOT SETTINGS ] =========================\\
global.style = process.env.STYLE   || '5'  // put '1' to "5" here to check bot styles
global.flush = process.env.FLUSH   || "false"; // Make it "true" if bot not responed
global.gdbye = process.env.GOODBYE || "true"; 
global.wlcm  = process.env.WELCOME || "true";  // Make it "false" for disable WELCOME 

global.warncount = process.env.WARN_COUNT || 3
global.disablepm = process.env.DISABLE_PM || "false"
global.disablegroup = process.env.DISABLE_GROUPS || "false", // disable bot in groups when public mode

global.MsgsInLog = process.env.MSGS_IN_LOG|| "false" // "true"  to see messages , "log" to show logs , "false" to hide logs messages
global.userImages= process.env.USER_IMAGES || "text" // set Image/video urls here
global.waPresence= process.env.WAPRESENCE ||  "null" ; // 'unavailable' | 'available' | 'composing' | 'recording' | 'paused'


//========================= [ AUTO READ MSGS & CMDS ] =========================\\
global.readcmds = process.env.READ_COMMAND || "false"
global.readmessage = process.env.READ_MESSAGE || "false"
global.readmessagefrom = process.env.READ_MESSAGE_FROM || "null,923xxxxxxxx";


//========================= [ AUTO SAVE & READ STATUS ] =========================\\
global.read_status = process.env.AUTO_READ_STATUS || "true"
global.save_status = process.env.AUTO_SAVE_STATUS || "false"
global.save_status_from =  process.env.SAVE_STATUS_FROM  || "null,923xxxxxxxx";
global.read_status_from =  process.env.READ_STATUS_FROM  ||  "923184474176,923xxxxxxxx";

global.api_smd = "https://api-smd.onrender.com" //  || "https://api-smd-1.vercel.app" // expires
global.scan = "https://suhail-md-vtsf.onrender.com";


global.SESSION_ID = process.env.SESSION_ID ||  "SUHAIL_07_27_07_01_ewogICJjcmVkcy5qc29uIjogIntcbiAgXCJub2lzZUtleVwiOiB7XG4gICAgXCJwcml2YXRlXCI6IHtcbiAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgXCJkYXRhXCI6IFtcbiAgICAgICAgMTY4LFxuICAgICAgICA1NixcbiAgICAgICAgMTg3LFxuICAgICAgICAzNCxcbiAgICAgICAgMTIwLFxuICAgICAgICAzOSxcbiAgICAgICAgMjQ0LFxuICAgICAgICAxMTYsXG4gICAgICAgIDc4LFxuICAgICAgICAyMTUsXG4gICAgICAgIDEzNCxcbiAgICAgICAgMTI0LFxuICAgICAgICA4NixcbiAgICAgICAgMjIyLFxuICAgICAgICA3MyxcbiAgICAgICAgMTAsXG4gICAgICAgIDIwNixcbiAgICAgICAgMjI5LFxuICAgICAgICAyMjcsXG4gICAgICAgIDE0MCxcbiAgICAgICAgMTUzLFxuICAgICAgICAxMDEsXG4gICAgICAgIDI0OCxcbiAgICAgICAgMTAyLFxuICAgICAgICA1MyxcbiAgICAgICAgMjM4LFxuICAgICAgICA5MSxcbiAgICAgICAgMTU0LFxuICAgICAgICAyOSxcbiAgICAgICAgMjMsXG4gICAgICAgIDIxNixcbiAgICAgICAgMTA5XG4gICAgICBdXG4gICAgfSxcbiAgICBcInB1YmxpY1wiOiB7XG4gICAgICBcInR5cGVcIjogXCJCdWZmZXJcIixcbiAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgIDEwMSxcbiAgICAgICAgMTIzLFxuICAgICAgICA4LFxuICAgICAgICAxNzMsXG4gICAgICAgIDE5NixcbiAgICAgICAgNzQsXG4gICAgICAgIDE3MCxcbiAgICAgICAgMjM1LFxuICAgICAgICAyMDksXG4gICAgICAgIDE0MyxcbiAgICAgICAgMjI4LFxuICAgICAgICAyMTcsXG4gICAgICAgIDIyOSxcbiAgICAgICAgMTU5LFxuICAgICAgICA0MyxcbiAgICAgICAgMjUxLFxuICAgICAgICAyMzgsXG4gICAgICAgIDgzLFxuICAgICAgICA4NyxcbiAgICAgICAgODAsXG4gICAgICAgIDE2NCxcbiAgICAgICAgMTM0LFxuICAgICAgICAyMDksXG4gICAgICAgIDkxLFxuICAgICAgICAxMDMsXG4gICAgICAgIDEzOCxcbiAgICAgICAgMTIwLFxuICAgICAgICAxNzYsXG4gICAgICAgIDEzOSxcbiAgICAgICAgMTA1LFxuICAgICAgICAxNzMsXG4gICAgICAgIDEwMVxuICAgICAgXVxuICAgIH1cbiAgfSxcbiAgXCJwYWlyaW5nRXBoZW1lcmFsS2V5UGFpclwiOiB7XG4gICAgXCJwcml2YXRlXCI6IHtcbiAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgXCJkYXRhXCI6IFtcbiAgICAgICAgMjI0LFxuICAgICAgICAyMTEsXG4gICAgICAgIDE0MyxcbiAgICAgICAgMTg3LFxuICAgICAgICA4LFxuICAgICAgICAxMjUsXG4gICAgICAgIDI1MCxcbiAgICAgICAgMTQ0LFxuICAgICAgICAyNDUsXG4gICAgICAgIDE4NixcbiAgICAgICAgMTM4LFxuICAgICAgICA5NSxcbiAgICAgICAgNTksXG4gICAgICAgIDE0MSxcbiAgICAgICAgNDYsXG4gICAgICAgIDExMCxcbiAgICAgICAgNjUsXG4gICAgICAgIDY3LFxuICAgICAgICAyNDksXG4gICAgICAgIDIyLFxuICAgICAgICAxMDcsXG4gICAgICAgIDEwNCxcbiAgICAgICAgMTUsXG4gICAgICAgIDIyLFxuICAgICAgICAxMSxcbiAgICAgICAgMTAsXG4gICAgICAgIDEzNCxcbiAgICAgICAgMTkwLFxuICAgICAgICAxMDMsXG4gICAgICAgIDk5LFxuICAgICAgICAxMjcsXG4gICAgICAgIDY3XG4gICAgICBdXG4gICAgfSxcbiAgICBcInB1YmxpY1wiOiB7XG4gICAgICBcInR5cGVcIjogXCJCdWZmZXJcIixcbiAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgIDI0LFxuICAgICAgICAxMTEsXG4gICAgICAgIDcxLFxuICAgICAgICA5MyxcbiAgICAgICAgOTksXG4gICAgICAgIDE1NyxcbiAgICAgICAgNDksXG4gICAgICAgIDUzLFxuICAgICAgICAzMSxcbiAgICAgICAgMTQwLFxuICAgICAgICA4NCxcbiAgICAgICAgNDEsXG4gICAgICAgIDIyMSxcbiAgICAgICAgMjAzLFxuICAgICAgICAyMjYsXG4gICAgICAgIDEzNyxcbiAgICAgICAgMzcsXG4gICAgICAgIDU1LFxuICAgICAgICAxMzUsXG4gICAgICAgIDQ2LFxuICAgICAgICAxODYsXG4gICAgICAgIDE0NSxcbiAgICAgICAgMTgyLFxuICAgICAgICA2MixcbiAgICAgICAgMTkwLFxuICAgICAgICAxMjAsXG4gICAgICAgIDEzOCxcbiAgICAgICAgMjA2LFxuICAgICAgICAyMjgsXG4gICAgICAgIDE5MyxcbiAgICAgICAgMjAxLFxuICAgICAgICA0MFxuICAgICAgXVxuICAgIH1cbiAgfSxcbiAgXCJzaWduZWRJZGVudGl0eUtleVwiOiB7XG4gICAgXCJwcml2YXRlXCI6IHtcbiAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgXCJkYXRhXCI6IFtcbiAgICAgICAgODAsXG4gICAgICAgIDIwMyxcbiAgICAgICAgMjU1LFxuICAgICAgICAyOCxcbiAgICAgICAgMTA0LFxuICAgICAgICAxMzksXG4gICAgICAgIDE4MixcbiAgICAgICAgNzYsXG4gICAgICAgIDE3OSxcbiAgICAgICAgMjAyLFxuICAgICAgICA2NSxcbiAgICAgICAgMjA2LFxuICAgICAgICAxMixcbiAgICAgICAgMjQsXG4gICAgICAgIDIxNyxcbiAgICAgICAgMjAsXG4gICAgICAgIDg5LFxuICAgICAgICAxNDgsXG4gICAgICAgIDUyLFxuICAgICAgICAxNDcsXG4gICAgICAgIDIyOCxcbiAgICAgICAgODAsXG4gICAgICAgIDIyMixcbiAgICAgICAgMTQ2LFxuICAgICAgICAxNjIsXG4gICAgICAgIDEwMyxcbiAgICAgICAgMTM0LFxuICAgICAgICAyNSxcbiAgICAgICAgMzAsXG4gICAgICAgIDQ1LFxuICAgICAgICAyNDksXG4gICAgICAgIDEwM1xuICAgICAgXVxuICAgIH0sXG4gICAgXCJwdWJsaWNcIjoge1xuICAgICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgICBcImRhdGFcIjogW1xuICAgICAgICAxNDIsXG4gICAgICAgIDIwNSxcbiAgICAgICAgMTksXG4gICAgICAgIDU5LFxuICAgICAgICAyNTAsXG4gICAgICAgIDE1LFxuICAgICAgICAxMjcsXG4gICAgICAgIDE0OSxcbiAgICAgICAgMjAwLFxuICAgICAgICA2NCxcbiAgICAgICAgMTQ4LFxuICAgICAgICAxNDksXG4gICAgICAgIDE5NixcbiAgICAgICAgNzIsXG4gICAgICAgIDE4MCxcbiAgICAgICAgMjM3LFxuICAgICAgICAyMDksXG4gICAgICAgIDIxNSxcbiAgICAgICAgMTM3LFxuICAgICAgICAxODEsXG4gICAgICAgIDE0MSxcbiAgICAgICAgNCxcbiAgICAgICAgMTUxLFxuICAgICAgICAxMjIsXG4gICAgICAgIDEwMixcbiAgICAgICAgMjQ4LFxuICAgICAgICAxNTYsXG4gICAgICAgIDIyNCxcbiAgICAgICAgNTEsXG4gICAgICAgIDc4LFxuICAgICAgICAxNzYsXG4gICAgICAgIDQ3XG4gICAgICBdXG4gICAgfVxuICB9LFxuICBcInNpZ25lZFByZUtleVwiOiB7XG4gICAgXCJrZXlQYWlyXCI6IHtcbiAgICAgIFwicHJpdmF0ZVwiOiB7XG4gICAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgICBcImRhdGFcIjogW1xuICAgICAgICAgIDE5MixcbiAgICAgICAgICAyMTMsXG4gICAgICAgICAgMyxcbiAgICAgICAgICAyMTksXG4gICAgICAgICAgMTY3LFxuICAgICAgICAgIDUsXG4gICAgICAgICAgMTQzLFxuICAgICAgICAgIDYyLFxuICAgICAgICAgIDE2OCxcbiAgICAgICAgICAxMTksXG4gICAgICAgICAgNzUsXG4gICAgICAgICAgNjMsXG4gICAgICAgICAgMjI1LFxuICAgICAgICAgIDE2MSxcbiAgICAgICAgICAyMzAsXG4gICAgICAgICAgMjIyLFxuICAgICAgICAgIDg0LFxuICAgICAgICAgIDIzMCxcbiAgICAgICAgICAxNDYsXG4gICAgICAgICAgMjQyLFxuICAgICAgICAgIDI0NCxcbiAgICAgICAgICAxNzMsXG4gICAgICAgICAgMTUzLFxuICAgICAgICAgIDE0NCxcbiAgICAgICAgICAxMTQsXG4gICAgICAgICAgMjA4LFxuICAgICAgICAgIDI1NSxcbiAgICAgICAgICAxMTAsXG4gICAgICAgICAgMTc3LFxuICAgICAgICAgIDI0LFxuICAgICAgICAgIDk1LFxuICAgICAgICAgIDg1XG4gICAgICAgIF1cbiAgICAgIH0sXG4gICAgICBcInB1YmxpY1wiOiB7XG4gICAgICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgICAgICBcImRhdGFcIjogW1xuICAgICAgICAgIDI1NSxcbiAgICAgICAgICAyMTAsXG4gICAgICAgICAgMjEsXG4gICAgICAgICAgMTI3LFxuICAgICAgICAgIDk5LFxuICAgICAgICAgIDQzLFxuICAgICAgICAgIDEyMCxcbiAgICAgICAgICAyMjEsXG4gICAgICAgICAgNDYsXG4gICAgICAgICAgMTA4LFxuICAgICAgICAgIDI0NSxcbiAgICAgICAgICAxMDksXG4gICAgICAgICAgMTUsXG4gICAgICAgICAgMjQxLFxuICAgICAgICAgIDE5MSxcbiAgICAgICAgICAxMDEsXG4gICAgICAgICAgMTA1LFxuICAgICAgICAgIDQ5LFxuICAgICAgICAgIDI5LFxuICAgICAgICAgIDY2LFxuICAgICAgICAgIDE5NixcbiAgICAgICAgICAyNTIsXG4gICAgICAgICAgNTMsXG4gICAgICAgICAgOTUsXG4gICAgICAgICAgMTg2LFxuICAgICAgICAgIDUwLFxuICAgICAgICAgIDExNixcbiAgICAgICAgICAyNCxcbiAgICAgICAgICA0LFxuICAgICAgICAgIDI0NyxcbiAgICAgICAgICAxMixcbiAgICAgICAgICAyM1xuICAgICAgICBdXG4gICAgICB9XG4gICAgfSxcbiAgICBcInNpZ25hdHVyZVwiOiB7XG4gICAgICBcInR5cGVcIjogXCJCdWZmZXJcIixcbiAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgIDIxMyxcbiAgICAgICAgMzUsXG4gICAgICAgIDIwOSxcbiAgICAgICAgMTE4LFxuICAgICAgICAxNTksXG4gICAgICAgIDE5LFxuICAgICAgICAxNTIsXG4gICAgICAgIDQsXG4gICAgICAgIDExNyxcbiAgICAgICAgMTgyLFxuICAgICAgICAyMjIsXG4gICAgICAgIDIxNyxcbiAgICAgICAgMTcyLFxuICAgICAgICAzNyxcbiAgICAgICAgODIsXG4gICAgICAgIDIxNCxcbiAgICAgICAgMjM5LFxuICAgICAgICAxNzEsXG4gICAgICAgIDEsXG4gICAgICAgIDM2LFxuICAgICAgICAxMTksXG4gICAgICAgIDM0LFxuICAgICAgICAxNjksXG4gICAgICAgIDIyNSxcbiAgICAgICAgMjE4LFxuICAgICAgICAxMTEsXG4gICAgICAgIDM5LFxuICAgICAgICAyMjAsXG4gICAgICAgIDE0NyxcbiAgICAgICAgMjAwLFxuICAgICAgICAxNzAsXG4gICAgICAgIDIyOSxcbiAgICAgICAgMjIxLFxuICAgICAgICAxNTAsXG4gICAgICAgIDMxLFxuICAgICAgICAyMzQsXG4gICAgICAgIDQ4LFxuICAgICAgICAyNDQsXG4gICAgICAgIDIyMyxcbiAgICAgICAgMSxcbiAgICAgICAgMzksXG4gICAgICAgIDIyMyxcbiAgICAgICAgMjQzLFxuICAgICAgICAxNjUsXG4gICAgICAgIDIyOCxcbiAgICAgICAgMTIwLFxuICAgICAgICAyMyxcbiAgICAgICAgOTIsXG4gICAgICAgIDM0LFxuICAgICAgICAyLFxuICAgICAgICAxMTAsXG4gICAgICAgIDM2LFxuICAgICAgICAzMixcbiAgICAgICAgMTY1LFxuICAgICAgICAyOCxcbiAgICAgICAgMjEwLFxuICAgICAgICAxOTAsXG4gICAgICAgIDE1MyxcbiAgICAgICAgMTMxLFxuICAgICAgICA3NyxcbiAgICAgICAgOTQsXG4gICAgICAgIDIyOCxcbiAgICAgICAgNjYsXG4gICAgICAgIDBcbiAgICAgIF1cbiAgICB9LFxuICAgIFwia2V5SWRcIjogMVxuICB9LFxuICBcInJlZ2lzdHJhdGlvbklkXCI6IDMwLFxuICBcImFkdlNlY3JldEtleVwiOiBcIlQyV0VscnZHayt3dC8yNXpOeWJ5bmFzejNyUzlMUnhHc2dlWmhPOEg0cHM9XCIsXG4gIFwicHJvY2Vzc2VkSGlzdG9yeU1lc3NhZ2VzXCI6IFtdLFxuICBcIm5leHRQcmVLZXlJZFwiOiAzMSxcbiAgXCJmaXJzdFVudXBsb2FkZWRQcmVLZXlJZFwiOiAzMSxcbiAgXCJhY2NvdW50U3luY0NvdW50ZXJcIjogMSxcbiAgXCJhY2NvdW50U2V0dGluZ3NcIjoge1xuICAgIFwidW5hcmNoaXZlQ2hhdHNcIjogZmFsc2VcbiAgfSxcbiAgXCJkZXZpY2VJZFwiOiBcImM4NFNvZkFwUTM2T1lIQWtQQ0dheGdcIixcbiAgXCJwaG9uZUlkXCI6IFwiMmZiNDE0OWMtYjQyYy00NWIxLWJmNjAtNzg5MWIxMzUxNjE0XCIsXG4gIFwiaWRlbnRpdHlJZFwiOiB7XG4gICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgXCJkYXRhXCI6IFtcbiAgICAgIDIxMSxcbiAgICAgIDg2LFxuICAgICAgMTksXG4gICAgICAxOTUsXG4gICAgICAyMDYsXG4gICAgICAxNCxcbiAgICAgIDI1NCxcbiAgICAgIDIwMyxcbiAgICAgIDIxLFxuICAgICAgMTAzLFxuICAgICAgNzIsXG4gICAgICAxOCxcbiAgICAgIDE0NyxcbiAgICAgIDI5LFxuICAgICAgMjA1LFxuICAgICAgMTY3LFxuICAgICAgMTg0LFxuICAgICAgOTEsXG4gICAgICA3NixcbiAgICAgIDE5NFxuICAgIF1cbiAgfSxcbiAgXCJyZWdpc3RlcmVkXCI6IHRydWUsXG4gIFwiYmFja3VwVG9rZW5cIjoge1xuICAgIFwidHlwZVwiOiBcIkJ1ZmZlclwiLFxuICAgIFwiZGF0YVwiOiBbXG4gICAgICAxOTgsXG4gICAgICAxNDksXG4gICAgICAyMzYsXG4gICAgICAxNDIsXG4gICAgICAxNjcsXG4gICAgICAxOSxcbiAgICAgIDIwOSxcbiAgICAgIDE0MSxcbiAgICAgIDEzLFxuICAgICAgODAsXG4gICAgICA4OCxcbiAgICAgIDIxOCxcbiAgICAgIDE4NCxcbiAgICAgIDE4MyxcbiAgICAgIDIsXG4gICAgICAyMDQsXG4gICAgICAxMTMsXG4gICAgICAxNTAsXG4gICAgICAyNTIsXG4gICAgICAyMzRcbiAgICBdXG4gIH0sXG4gIFwicmVnaXN0cmF0aW9uXCI6IHt9LFxuICBcInBhaXJpbmdDb2RlXCI6IFwiU1lIQjNaUVdcIixcbiAgXCJtZVwiOiB7XG4gICAgXCJpZFwiOiBcIjI1NTY5NDE4NzAwODo1QHMud2hhdHNhcHAubmV0XCIsXG4gICAgXCJuYW1lXCI6IFwiSzI5XCIsXG4gICAgXCJsaWRcIjogXCIyNDA2NzMyNTcxNjkxMTk6NUBsaWRcIlxuICB9LFxuICBcImFjY291bnRcIjoge1xuICAgIFwiZGV0YWlsc1wiOiBcIkNOUzZ2dTBIRU1hMGliUUdHQVVnQUNnQVwiLFxuICAgIFwiYWNjb3VudFNpZ25hdHVyZUtleVwiOiBcIlBuM01ESG4yS0FWZ3l5cjBLOUtnSkJIakNyUjZndFZzUEV5QWlFOWtWV1U9XCIsXG4gICAgXCJhY2NvdW50U2lnbmF0dXJlXCI6IFwiRld4dWk0c0hmL2lLZS9DdmFTanBBZjkxWnY2bm9YVVBDMHNtbmRicm9PcGJucEVCQWpwZTZpTjV1SkxPeWJjblBnRHlyMGd2cXNhTXFqcHF3Q01YRFE9PVwiLFxuICAgIFwiZGV2aWNlU2lnbmF0dXJlXCI6IFwiakZZOWl1Q2l0ZCsvZDVWb2ZGRVJ3eDZWRFFka3ZmenRuVDYrOUdqaWI5cTBEL0cxRUZoZ1c4bVZoWFVSZlU0YTRncmpyckhXeTZydDlCcGdSVWx2Q3c9PVwiXG4gIH0sXG4gIFwic2lnbmFsSWRlbnRpdGllc1wiOiBbXG4gICAge1xuICAgICAgXCJpZGVudGlmaWVyXCI6IHtcbiAgICAgICAgXCJuYW1lXCI6IFwiMjU1Njk0MTg3MDA4OjVAcy53aGF0c2FwcC5uZXRcIixcbiAgICAgICAgXCJkZXZpY2VJZFwiOiAwXG4gICAgICB9LFxuICAgICAgXCJpZGVudGlmaWVyS2V5XCI6IHtcbiAgICAgICAgXCJ0eXBlXCI6IFwiQnVmZmVyXCIsXG4gICAgICAgIFwiZGF0YVwiOiBbXG4gICAgICAgICAgNSxcbiAgICAgICAgICA2MixcbiAgICAgICAgICAxMjUsXG4gICAgICAgICAgMjA0LFxuICAgICAgICAgIDEyLFxuICAgICAgICAgIDEyMSxcbiAgICAgICAgICAyNDYsXG4gICAgICAgICAgNDAsXG4gICAgICAgICAgNSxcbiAgICAgICAgICA5NixcbiAgICAgICAgICAyMDMsXG4gICAgICAgICAgNDIsXG4gICAgICAgICAgMjQ0LFxuICAgICAgICAgIDQzLFxuICAgICAgICAgIDIxMCxcbiAgICAgICAgICAxNjAsXG4gICAgICAgICAgMzYsXG4gICAgICAgICAgMTcsXG4gICAgICAgICAgMjI3LFxuICAgICAgICAgIDEwLFxuICAgICAgICAgIDE4MCxcbiAgICAgICAgICAxMjIsXG4gICAgICAgICAgMTMwLFxuICAgICAgICAgIDIxMyxcbiAgICAgICAgICAxMDgsXG4gICAgICAgICAgNjAsXG4gICAgICAgICAgNzYsXG4gICAgICAgICAgMTI4LFxuICAgICAgICAgIDEzNixcbiAgICAgICAgICA3OSxcbiAgICAgICAgICAxMDAsXG4gICAgICAgICAgODUsXG4gICAgICAgICAgMTAxXG4gICAgICAgIF1cbiAgICAgIH1cbiAgICB9XG4gIF0sXG4gIFwicGxhdGZvcm1cIjogXCJzbWJhXCIsXG4gIFwibGFzdEFjY291bnRTeW5jVGltZXN0YW1wXCI6IDE3MTk4MTg4MjUsXG4gIFwibXlBcHBTdGF0ZUtleUlkXCI6IFwiQUFBQUFCOWRcIlxufSIsCiAgImFwcC1zdGF0ZS1zeW5jLWtleS1BQUFBQUI5ZC5qc29uIjogIntcImtleURhdGFcIjpcIlkxMmpFZldmSEwzNHVYQyt3cW42MkJNUFdIRjdxQ3BzcjVjWVdWU0lPTVU9XCIsXCJmaW5nZXJwcmludFwiOntcInJhd0lkXCI6MjEwODY2MTA3NixcImN1cnJlbnRJbmRleFwiOjEsXCJkZXZpY2VJbmRleGVzXCI6WzAsMV19LFwidGltZXN0YW1wXCI6XCIwXCJ9Igp9"  // PUT your SESSION_ID 


module.exports = {

  menu: process.env.MENU || "", /**  Available @MENU @Schemes 1: Aztec_Md, 2: A17_Md, 3: Suhail-Md Default ---------- If Not Choose then it Randomely Pic One Of Them Each time **/

  HANDLERS: process.env.PREFIX  || ".",
  BRANCH  : process.env.BRANCH  || "main",
  VERSION : process.env.VERSION || "1.3.4",
  caption : process.env.CAPTION || "©sᴜʜᴀɪʟ²²¹-ᴍᴅ" , // ```『 ᴘᴏᴡᴇʀᴇᴅ ʙʏ sᴜʜᴀɪʟ²²¹-ᴍᴅ 』```", //*『sᴜʙsᴄʀɪʙᴇ • sᴜʜᴀɪʟ ᴛᴇᴄʜ』*\n youtube.com/@suhailtechinfo0"),
 
  author : process.env.PACK_AUTHER|| "K29",
  packname: process.env.PACK_NAME || "K29",
  botname : process.env.BOT_NAME  || "K29",
  ownername:process.env.OWNER_NAME|| "Javan",


  errorChat : process.env.ERROR_CHAT || "",
  KOYEB_API : process.env.KOYEB_API  || "false",

  REMOVE_BG_KEY : process.env.REMOVE_BG_KEY  || "",
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || "sk-proj-YkAMrlbKEHFxrKzBQcHYT3BlbkFJ100pXylj15rDLYZlKqCr",
  HEROKU_API_KEY: process.env.HEROKU_API_KEY || "",
  HEROKU_APP_NAME:process.env.HEROKU_APP_NAME|| "",
  antilink_values:process.env.ANTILINK_VALUES|| "all",
  HEROKU: process.env.HEROKU_APP_NAME && process.env.HEROKU_API_KEY,


  WORKTYPE: process.env.WORKTYPE || process.env.MODE|| "public",
  LANG: ( process.env.THEME ||  "SUHAIL"  ).toUpperCase(),



};



global.ELEVENLAB_API_KEY = process.env.ELEVENLAB_API_KEY || "";
global.aitts_Voice_Id = process.env.AITTS_ID|| "37";





















global.rank = "updated"
global.isMongodb = false; 
let file = require.resolve(__filename)
fs.watchFile(file, () => { fs.unwatchFile(file);console.log(`Update'${__filename}'`);delete require.cache[file];	require(file); })
 

// ========================= [ Disables in V.1.2.8 ] ===============================\\  
  //style : process.env.STYLE || "2",  // put '1' & "2" here to check bot styles
  //readmessage:process.env.READ_MESSAGE|| "false",
  //warncount: process.env.WARN_COUNT || 3,
  //userImages:process.env.USER_IMAGES|| "text",  // SET IMAGE AND VIDEO URL FOR BOT MENUS 
  //disablepm: process.env.DISABLE_PM || "false",
  //MsgsInLog: process.env.MSGS_IN_LOG|| "false", // "true"  to see messages , "log" to open logs , "false" to hide logs messages
  //readcmds:process.env.READ_COMMANDS|| "false", 
  //alwaysonline:process.env.WAPRESENCE|| "unavailable", // 'unavailable' | 'online' | 'composing' | 'recording' | 'paused'
  //read_status: process.env.AUTO_READ_STATUS || "false",
  //save_status: process.env.AUTO_SAVE_STATUS || "false",
  //aitts_Voice_Id : process.env.AITTS_ID || "37",
  //ELEVENLAB_API_KEY: process.env.ELEVENLAB_API_KEY  || "",
